#include <stdio.h>
#include "cs50.h"

int main(void)
{
    eprintf("hello, %s\n", "world");
}
